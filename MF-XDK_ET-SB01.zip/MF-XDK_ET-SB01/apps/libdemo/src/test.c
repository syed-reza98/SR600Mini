#include <stdio.h>
int libtestadd(int a , int b)
{
	return a+b;
}
