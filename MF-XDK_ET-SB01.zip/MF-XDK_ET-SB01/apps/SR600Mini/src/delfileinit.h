/**
 * @file delfileinit.h
 * @author CHAR
 * @brief 
 * @date 2023-11-22
 * @copyright Fujian MoreFun Electronic Technology Co., Ltd.
 */
#ifndef __DELFILEINIT_H__
#define __DELFILEINIT_H__


#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */

LIB_EXPORT void delfile_init();

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif /* __DELFILEINIT_H__ */
