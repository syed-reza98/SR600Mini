#pragma once
#include "lvgl/lvgl.h"

char * get_trans_title(int transType);
void MainMenu();
void SettingPage(char *title);

