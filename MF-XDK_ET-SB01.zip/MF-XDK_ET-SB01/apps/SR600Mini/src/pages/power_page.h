#pragma once

void app_power_page_show(int msg);

