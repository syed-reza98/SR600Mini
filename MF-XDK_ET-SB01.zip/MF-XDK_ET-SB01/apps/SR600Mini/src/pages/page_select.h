#pragma once
#include "lvgl/lvgl.h"

void create_select_page(lv_obj_t* parent, char *title, char*key, char* item[], int count, int timeover);

