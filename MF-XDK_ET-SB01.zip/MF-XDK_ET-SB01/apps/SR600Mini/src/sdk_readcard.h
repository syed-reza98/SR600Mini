#pragma once

#include "libapi_xpos/inc/emvapi.h"


#define SUCC 0
#define FAIL (-1)

int sdk_readcard_init(void);