#pragma once
#include "lvgl/lvgl.h"
int func_wifi_info(lv_obj_t* parent);
int func_wifi_show(lv_obj_t* parent);
void func_wifi_show_ex();

