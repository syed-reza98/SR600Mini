#pragma once

int http_sync();