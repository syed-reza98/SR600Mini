#if defined(_MF_MODULE_COMM_L_)
#include "libapi_comm_mf_l_platform.h"
#else
#include "libapi_comm_mf_r_platform.h"
#endif

