#if defined(_MF_MODULE_SYSTEM_L_)
#include "libapi_system_mf_l_platform.h"
#else
#include "libapi_system_mf_r_platform.h"
#endif
